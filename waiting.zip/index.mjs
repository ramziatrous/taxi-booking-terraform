import { DynamoDBClient, ScanCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { SNS } from "@aws-sdk/client-sns";
import { SQSClient, SendMessageBatchCommand } from "@aws-sdk/client-sqs";


const sns = new SNS({ region: "eu-central-1" });
const sqs = new SQSClient({ region: "eu-central-1" });

const dynamoDB = new DynamoDBClient({ region: "eu-central-1" });

export const handler = async (event, context) => {
    const params = {
        TableName: 'drivers'
    };

    try {
        const scanCommand = new ScanCommand(params);
        const data = await dynamoDB.send(scanCommand);
        const available_fahrer = data.Items.filter(item => item.available && item.available.BOOL === true);
        console.log(available_fahrer);
        for (const record of event.Records) {
            try {
                const payload = JSON.parse(record.body);
                if (available_fahrer.length > 0) {
                    const itemToUpdate = available_fahrer[0];

                    const client = JSON.stringify(payload.Name);
                    const bid = JSON.stringify(payload.bookingid);

                    const updateParams = {
                        TableName: 'drivers',
                        Key: {
                            'fahrer_Id': { S: itemToUpdate.fahrer_Id.S }
                        },
                        UpdateExpression: 'SET available = :val, client_name = :var,booking_id = :id',
                        ExpressionAttributeValues: {
                            ':val': { BOOL: false },
                            ':var': { S: client },
                            ':id' : {S:bid}
                        }
                    };

                    const updateCommand = new UpdateItemCommand(updateParams);
                    await dynamoDB.send(updateCommand);


                    const paramsSNS = {
                        Message: JSON.stringify(payload),
                        Subject: 'reservation',
                        TopicArn: 'arn:aws:sns:eu-central-1:992342464544:tf_sns_topic',
                    };

                    await sns.publish(paramsSNS);

                    return {
                        statusCode: 200,
                        body: JSON.stringify({ message: 'Item updated successfully.' })
                    };

                } else {
                    console.error('all the driverss are unavailable');


                    const paramsSQS = {
                        QueueUrl: 'https://sqs.eu-central-1.amazonaws.com/992342464544/tf_waiting_liste',
                        Entries: [
                            {
                                Id: '1',
                                MessageBody: record.body
                            }
                        ]
                    };

                    await sqs.send(new SendMessageBatchCommand(paramsSQS));


                    return {
                        statusCode: 500,
                        body: JSON.stringify({ message: 'your reservation in the waiting list' })
                    };
                }
            } catch (err) {
                console.error('Error:', err);
                return {
                    statusCode: 500,
                    body: JSON.stringify({ message: 'Error updating item.' })
                };
            }
        }

    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error updating item.' })
        };
    }
};
