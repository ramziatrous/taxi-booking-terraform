import { DynamoDBClient, QueryCommand } from "@aws-sdk/client-dynamodb";




const dynamoDBClient = new DynamoDBClient({ region: "eu-central-1" });
const tableName = "drivers";

export const handler = async (event,context) => {
  const booking_id = event.pathParameters.booking_id; 

  const params = {
  TableName: tableName,
  IndexName: "booking_id-index",
  KeyConditionExpression: "#booking_id = :booking_id",
  ExpressionAttributeNames: {
    "#booking_id": "booking_id",
  },
  ExpressionAttributeValues: {
    ":booking_id": { S: booking_id },
  },
};



  try {
    const command = new QueryCommand(params);
    const { Items } = await dynamoDBClient.send(command);

    if (Items) {
      return {
        statusCode: 200,
        body: JSON.stringify(Items),
      };
    } else {
    }
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error fetching user", error: error.message }),
    };
  }
};
